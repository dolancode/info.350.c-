﻿
public class Program
{

    private static void Greeting()
    {
        Console.WriteLine("Welcome to course grade evaluator");
    }

    private static float GetGrade(int gradeNumber)
    {
        Console.WriteLine($"Enter Grade {gradeNumber} in form 0.0");
        return float.Parse(Console.ReadLine());

    }
    private static float CalculateGrade(List<float> grades)
    {
        return grades.Average();
    }

    private static void DisplayResult(string courseName, float grade)
    {
        Console.WriteLine($"average for {courseName} is {grade}");
    }


    public static void Main()
    {

        List<float> grades = new List<float>();

        Program.Greeting();

        Console.WriteLine("Enter Course Name");
        string courseName = Console.ReadLine();

        grades.Add(Program.GetGrade(1));
        grades.Add(Program.GetGrade(2));
        grades.Add(Program.GetGrade(3));

        float average = Program.CalculateGrade(grades);

        Program.DisplayResult(courseName, average);

    }
}